import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np
import pickle
from util import *
from fetch import getTest, getTrain

TRAIN_AUTOENCODER = 0 
TRAIN_NET = 1

TOTAL_AE = 250000
TOTAL_MLP = 750000

BS_AE = 20
BS_MLP = 50
EPOCHS_AE = 50 
EPOCHS_MLP = 201 
RATE_AE = 0.005
DECAY_AE = 0.98
RATE_MLP = 0.005
DECAY_MLP = 0.98

BIAS = 0.15

N_INPUT = 769 
ENCODING_1 = 600 
ENCODING_2 = 400 
ENCODING_3 = 200
ENCODING_4 = 100

HIDDEN_1 = 200
HIDDEN_2 = 400 
HIDDEN_3 = 200
HIDDEN_4 = 100 
N_OUT = 2

VOLUME_SIZE = 25000
export_path = '../Export/exports'


train_data = getTrain(input_size, total_samples, volume_size)
train_positions = train_data[0]

# Fetch the test data
test_start = 0
test_finish = 10
test_data = getTest(input_size, test_start, test_finish)
test_positions, test_labels = test_data

# Create the dataset and dataloader for the Pos2Vec DBN training
train_dataset = ChessDataset(train_positions)
train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)

# Create the dataset and dataloader for the Pos2Vec DBN testing
test_dataset = ChessDataset(test_positions)
test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# Initialize the Pos2Vec DBN model
pos2vec_dbn = Pos2VecDBN()

# Define the loss function and optimizer for the Pos2Vec DBN
criterion = nn.MSELoss()
optimizer = optim.SGD(pos2vec_dbn.parameters(), lr=0.005)

# Train the Pos2Vec DBN
train_pos2vec_dbn(pos2vec_dbn, train_dataloader, criterion, optimizer, num_epochs)

# Evaluate the Pos2Vec DBN on the test data
pos2vec_dbn.eval()
with torch.no_grad():
    test_loss = 0.0
    for inputs in test_dataloader:
        outputs = pos2vec_dbn(inputs)
        loss = criterion(outputs, inputs)
        test_loss += loss.item()
    avg_test_loss = test_loss / len(test_dataloader)
    print(f"Average Test Loss: {avg_test_loss:.4f}")
